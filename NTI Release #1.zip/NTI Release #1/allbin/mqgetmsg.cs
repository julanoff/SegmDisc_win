// Library:       WebSphere MQ
// Component:     MQ.NET Sample Programs
// Part:          NMQSGET.CS
//
// Description:   Sample C# program that gets messages from a named
//                queue.
//
//                NMQSGET has 3 parameters:
//                - the name of a queue (required)
//                - the name of a queue manager (optional)
//                - the definition of a channel (optional)
//
//                If no queue manager name is given, the queue manager
//                defaults to the default local queue manager. If a
//                channel is defined, it should have the same format
//                as the MQSERVER environment variable.
//  <START_COPYRIGHT> 
//  Licensed Materials - Property of IBM 
//                   
//  5724-B41         
//  (C) Copyright IBM Corp. 1994, 2003 All Rights Reserved. 
//                   
//  US Government Users Restricted Rights - Use, duplication or 
//  disclosure restricted by GSA ADP Schedule Contract with 
//  IBM Corp.        
//  <END_COPYRIGHT>  

using System;
using IBM.WMQ;


namespace nmqsget
{
	/// <summary>
	/// Summary description for nmqsget.
	/// </summary>
	class nmqsget
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static int Main(String[] args)
		{
			MQQueueManager      mqQMgr;          // MQQueueManager instance
			MQQueue             mqQueue;         // MQQueue instance
			String              queueName;       // Name of queue to use

			System.Console.WriteLine( "Sample NMQSGET start" );
			if (args.Length == 0) 
			{
				System.Console.WriteLine("Required parameter missing - queue name" );
				return( (int)99 );
			}
			else 
			{
				queueName = args[0];
			}

			///
			/// Try to create an MQQueueManager instance 
			/// 
			try 
			{
				if (args.Length > 2) 
				{
					// queue name, queue manager name, channel definition all provided

					// Break down the channel definition,
					// which is of the form "channel-name/transport-type/connection-name".
					String channelDefinition = args[2];
					String channelName = "";
					String transportType = "";
					String connectionName = "";
					char[] separator = {'/'};
					String[] parts;
					parts = channelDefinition.Split( separator );
					if (parts.Length > 0) channelName = parts[0];
					if (parts.Length > 1) transportType = parts[1];
					if (parts.Length > 2) connectionName = parts[2];
					mqQMgr = new MQQueueManager( args[1], channelName, connectionName );
				}
				else
					if (args.Length == 2) 
				{
					// queue name, queue manager name provided
					mqQMgr = new MQQueueManager( args[1] );
				}
				else
				{
					// queue name provided - use default queue manager
					mqQMgr = new MQQueueManager();
				}
			}
			catch (MQException mqe) 
			{
				// stop if failed
				System.Console.WriteLine( "create of MQQueueManager ended with " + mqe.Message );
				return( (int)mqe.Reason );
			}

			///
			/// Try to open the queue
			///
			try 
			{
				mqQueue = mqQMgr.AccessQueue( queueName, 
					                          MQC.MQOO_INPUT_AS_Q_DEF             // open queue for input
					                          + MQC.MQOO_FAIL_IF_QUIESCING );     // but not if MQM stopping
			}
			catch (MQException mqe) 
			{
				// stop if failed
				System.Console.WriteLine( "MQQueueManager::AccessQueue ended with " + mqe.Message );
				return( (int)mqe.Reason );
			}

			///
			/// Get messages from the message queue
			/// Loop until there is a failure
			/// 
			bool isContinue = true;
			while (isContinue) 
			{
				MQMessage           mqMsg;           // MQMessage instance
				MQGetMessageOptions mqGetMsgOpts;    // MQGetMessageOptions instance

				mqMsg = new MQMessage();
				mqGetMsgOpts = new MQGetMessageOptions();
				mqGetMsgOpts.WaitInterval = 15000;  // 15 second limit for waiting
				try 
				{
					mqQueue.Get( mqMsg, mqGetMsgOpts );
					if (mqMsg.Format.CompareTo(MQC.MQFMT_STRING) == 0) 
					{
						System.Console.WriteLine(  mqMsg.ReadString(mqMsg.MessageLength) );
					}
					else 
					{
						System.Console.WriteLine( "Non-text message" );
					}
				}
				catch (MQException mqe) 
				{
					// report reason, if any
					if ( mqe.Reason == MQC.MQRC_NO_MSG_AVAILABLE ) 
					{
						// special report for normal end
						System.Console.WriteLine( "no more messages" );
						isContinue = false;
					} 
					else 
					{
						// general report for other reasons
						System.Console.WriteLine( "MQQueue::Get ended with " + mqe.Message );

						// treat truncated message as a failure for this sample
						if ( mqe.Reason == MQC.MQRC_TRUNCATED_MSG_FAILED ) 
						{
							isContinue = false;
						}
					}
				}
			}

			System.Console.WriteLine( "Sample NMQSGET end" );
			return (0);
		}
	}
}
