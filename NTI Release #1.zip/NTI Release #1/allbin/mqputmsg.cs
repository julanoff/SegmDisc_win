using System;
using System.IO;
using System.Text;
using IBM.WMQ;

namespace Mqputmsg
{
	/// <summary>
	/// Summary description for mqputmsg.
	/// </summary>
	public class Mqputmsg
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		MQQueueManager      	mqQMgr;          // MQQueueManager instance
		MQQueue             	mqQueue;         // MQQueue instance
		MQMessage           	mqMsg;           // MQMessage instance
		MQPutMessageOptions 	mqPutMsgOpts;    // MQPutMessageOptions instance
		private	string 		fileName;
		private	string          queueName;       // Name of queue to use
		private	string          message;         // Message buffer
		private	string          msgstr="";       // Message buffer
		FileStream InFile;
		StreamReader sread;

		private void writemsg(string msgstr)
		{
		// put the next message to the queue
			mqMsg = new MQMessage();
			mqMsg.Format = MQC.MQFMT_STRING;
			mqMsg.Encoding = MQC.MQENC_NATIVE;
			mqMsg.CharacterSet = 437;
//mqMsg.OriginalLength=message.Length;
			mqMsg.WriteString( msgstr );
			int aa = msgstr.Length;
			mqPutMsgOpts = new MQPutMessageOptions();
			try
			{
				mqQueue.Put( mqMsg, mqPutMsgOpts );
				Console.WriteLine("msg added - "+msgstr);
			}
			catch (MQException mqe)
			{ // report the error
				System.Console.WriteLine( "MqPutMsg::Put ended with " + mqe.Message );
			}
		}

		[STAThread]
		static void Main(string[] args)
		{
			Mqputmsg mqputmsg = new Mqputmsg();
			mqputmsg.Run(args);
		}

		private int Run(string [] args)
		{
			Console.WriteLine( "MqPutMsg starts ");
			if (args.Length < 1) 
			{
				System.Console.WriteLine("Required parameter missing - queue name, file name" );
				return( (int)99 );
			}
			else 
			{
				queueName = args[0];
				fileName = "c:/temp/cprog/"+args[1];
			}
			Console.Write("filename = "+fileName+"\n\r");
			///
			/// Try to create an MQQueueManager instance 
			/// 
			try 
			{
				// queue name provided - use default queue manager
				mqQMgr = new MQQueueManager();
			}
			catch (MQException mqe) 
			{
				// stop if failed
				System.Console.WriteLine( "create of MQQueueManager ended with " + mqe.Message );
				return( (int)mqe.Reason );
			}

			///
			/// Try to open the queue
			///
			try 
			{
				mqQueue = mqQMgr.AccessQueue( queueName, 
	                          MQC.MQOO_OUTPUT                   // open queue for output
	                          + MQC.MQOO_FAIL_IF_QUIESCING );   // but not if MQM stopping
			}
			catch (MQException mqe) 
			{
				// stop if failed
				System.Console.WriteLine( "MQQueueManager::AccessQueue ended with " + mqe.Message );
				return( (int)mqe.Reason );
			}
			InFile = new FileStream(fileName, FileMode.Open, FileAccess.Read);
			sread = new StreamReader(InFile);

			do
			{
				message = sread.ReadLine();
				if (message != null)
				{
					if (message.IndexOf("<msg end>") != -1)
					{
						if (msgstr.Substring(0,1) == "\r")
							writemsg(msgstr.Substring(2,msgstr.Length - 2));
						else
							writemsg(msgstr);
						msgstr="";
					}
					else
						msgstr+=message;

						if (fileName.ToUpper().IndexOf("SWF") != -1)
							msgstr+="\r\n";
				}
				else
					break;
			} while (true);
			sread.Close();		
			InFile.Close();
			System.Console.WriteLine( "MqPutMsg end" );
			return (0);
		}
	}
}