/*  FNI_REGEXPR.C  */
/* Routine to evalute strings using regular epressions*/
/*
 * Revision history:
 *
 * 02-Apr-09   J Novak Initial version
*/

#include <ctype.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <sys/stat.h>
#include <regex.h>

int FNI_REGEXPR(char *regexpr, size_t *regexpr_length,
                        char *match_string, size_t *match_length )
{

int 		result;
regex_t	    re;
char errbuf[256];
char 		*pc;

    pc=match_string + *match_length;
    *pc='\0';
/*	printf ("Cheking %s inside %s\n", regexpr, match_string);*/
 	result = regcomp(&re, regexpr, REG_EXTENDED|REG_NOSUB|REG_ICASE);
    if ( result != 0) {
		regerror(result,regexpr,errbuf,256);
        printf("Invalid pattern \"%s\": %s\n",
                      regexpr,errbuf);
		return(0);      /* Report error. */
    }
    result = regexec(&re, match_string, (size_t) 0, NULL, 0);
    regfree(&re);
    if (result != 0) {
         return(0);      /* Report error. */
    }
     return(1);
 }
