#!/usr/local/bin/bash

## Copyright (c) The Bank of New York, New York, April, 2006.
## All Rights Reserved.
## Valid parameters:
##
## THROTTLE ON/OFF
## LISTPRIO
## OPENBALANCE AMOUNT
## DEBITCAP AMOUNT
## INTERNALCAP AMOUNT
## 

case  $1 in
THROTTLE)
	case $2 in
	ON)
		echo Setting: Credit Checking ON
		psr_ch -p THROTTLE -a ON
		idi -db_dump -nostat psr:bny/psr fed_throttle_ind: end: | grep -i FED_THROTTLE_IND:\" | sed "s/FED_THROTTLE_IND://"
		;;
	OFF)
		echo Setting: Credit Checking OFF
		psr_ch -p THROTTLE -a OFF
		idi -db_dump -nostat psr:bny/psr fed_throttle_ind: end: | grep -i FED_THROTTLE_IND:\" | sed "s/FED_THROTTLE_IND://"
		;;
	HOLD)
		echo Setting: Hold ALL Items ON
		psr_ch -p THROTTLE -a HOLD
		idi -db_dump -nostat psr:bny/psr fed_throttle_ind: end: | grep -i FED_THROTTLE_IND:\" | sed "s/FED_THROTTLE_IND://"
		;;
	*)
		echo Invalid command for THROTTLE. Must be ON, HOLD or OFF
		;;
	esac
        ;;

LISTPRIO)
	echo LIST PRIORITY/SUPER PRIORITY ACCOUNTS
	idi -db_dump -nostat profile:/system all: end: | grep -i SPEC_ACCNTS|sed "s/PARAM_SEQ:\"MTS\$SPEC_ACCNTS\/NOTHING\///" 
	;;

OPENBAL)
	echo Setting: Openning Balance to $2
        psr_ch -p OPENBAL -a $2
	idi -db_dump -nostat psr:bny/psr fed_open_bal: end: | grep -i fed_open_bal:\" | tail -1 | sed "s/FED_OPEN_BAL://"
	;;

DEBITCAP)
        echo Setting: Debit Cap to $2
        psr_ch -p DEBITCAP -a $2
        idi -db_dump -nostat psr:bny/psr fed_dbt_cap: end: | grep -i fed_dbt_cap:\" | tail -1 | sed "s/FED_DBT_CAP://"
        ;;
THRESHHOLD)
        echo Setting: HOLD Threshhold to $2
        psr_ch -p THRESHHOLD -a $2
        idi -db_dump -nostat psr:bny/psr fed_thresh: end: | grep -i fed_thresh:\" | tail -1 | sed "s/FED_THRESH://"
        ;;
INTERNALCAP)
        echo Setting: Internal Cap to $2
        psr_ch -p INTERNALCAP -a $2
        idi -db_dump -nostat psr:bny/psr fed_internal_cap: end: | grep -i fed_internal_cap:\" | tail -1 | sed "s/FED_INTERNAL_CAP://"
        ;;

*)
        echo REQUEST is not valid $1
        ;;
esac

