alloc_que -n ASI_TBL_NDX -t GEN_VSTR_INDEX -d STATIC -o NULL -ape -m "FED92 impl"
alloc_que -n FED_92Q -b BNY -t GEN_WORK_QUE -d STATIC  -o MSG_HISTORY_SEQ -ape -m "FED92 impl"
alloc_que -n FED92_LOG -b BNY -t OPR_ACTION_LOG -d MESSAGE -o MSG_HISTORY_SEQ -pe -m "FED92 impl"
